<?php
include 'dbconn.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Car Rental Company Back Office Operations</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #f4f4f4;
    }
    .container {
        width: auto;  
        min-width: 320px;  
        max-width: 95%;  
        margin: 20px auto;  
        padding: 20px;  
        background: white;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        overflow-x: auto;  
    }

    form {
        display: grid;
        grid-template-columns: 1fr 2fr;
        gap: 10px;
        align-items: center;
        margin-bottom: 20px;
    }
    form label {
        text-align: right;
        padding-right: 10px;
    }
    input[type="text"], select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    input[type="submit"] {
        padding: 10px 20px;
        color: white;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        text-align: left;
        padding: 8px;
        border: 1px solid #ddd;
    }
    th {
        background-color: #f8f8f8;
    }
    button {
        padding: 5px 10px;
        background-color: #f44336;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background-color: #d32f2f;
    }
</style>
</head>
<body>
<div class="container">    
    <h1>Car Rental Company Back Office Operations</h1>
    <ul>
        <li><a href="create_store.php">Store Operations - Create Update Delete</a></li>
        <li><a href="create_employee.php">Employee Operations - Create Update Delete</a></li>
        <li><a href="manage_staff.php">Manage Store Staff</a></li>
        <li><a href="create_car_maker.php">Car Maker Operations - Add Update Delete</a></li>
        <li><a href="create_cars_for_inventory.php">Car Operattion - Create Cars</a></li>
        <li><a href="update_car_for_rent.php">Car Operations - Update or Delet Cars</a></li>
        <li><a href="create_update_inventory.php">Manage Store Inventory of Cars</a></li>
        <br>
        <li><a href="store_income_projection.php">Create Projected Income Report</a></li>
        <br>
        <br>
        <li><a href="logout.php">Sign Out</a></li>
    </ul>
</div>
</body>
</html>

<?php
include('dbconn.php'); 
ob_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['confirm']) && $_POST['confirm'] == 'yes') {
        // User has confirmed the deletion
        $staff_id = intval($_POST['staff_id']);
        $address_id = intval($_POST['address_id']);
        $city_id = intval($_POST['city_id']);

        
        $conn->begin_transaction();

        try {
            
            $stmt = $conn->prepare("DELETE FROM staff WHERE staff_id = ?");
            $stmt->bind_param("i", $staff_id);
            $stmt->execute();
            $stmt->close();

            
            $stmt = $conn->prepare("DELETE FROM address WHERE address_id = ?");
            $stmt->bind_param("i", $address_id);
            $stmt->execute();
            $stmt->close();

            
            $stmt = $conn->prepare("DELETE FROM city WHERE city_id = ?");
            $stmt->bind_param("i", $city_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            // Redirect to avoid re-posting data
            header("Location: create_employee.php");
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo "An error occurred: " . $e->getMessage();
            exit();
        }
    } elseif (isset($_POST['confirm']) && $_POST['confirm'] == 'no') {
        // If user selects 'No', redirect to create_employee.php
        header("Location: create_employee.php");
        exit();
    }
}

if (isset($_GET['staff_id']) && !isset($_POST['confirm'])) {
    
    $staff_id = intval($_GET['staff_id']);
    $query = "SELECT s.staff_id, s.first_name, s.last_name, a.address_id, a.address, c.city_id, c.city 
              FROM staff s
              JOIN address a ON s.address_id = a.address_id
              JOIN city c ON a.city_id = c.city_id
              WHERE s.staff_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();

    if (!$data) {
        echo "<p>Employee not found.</p>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Delete Employee</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        width: 80%;
        margin: auto;
        background: white;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
        color: #333;
    }
    ul {
        list-style: none;
        padding: 0;
    }
    ul li {
        margin-bottom: 10px;
        font-size: 16px;
    }
    form {
        margin-top: 20px;
    }
    input[type="radio"] {
        margin-right: 5px;
    }
    button {
        padding: 10px 20px;
        color: #fff;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    button:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>
<div class="container">
    <a href="create_employee.php" class="back-button">Back to Employee Creation Page</a>
    <h2>Confirm Deletion</h2>
    <?php if (isset($data)): ?>
        <p>Are you sure you want to delete the following employee and its related address and city?</p>
        <ul>
            <li>Employee Name: <?= htmlspecialchars($data['first_name']) . ' ' . htmlspecialchars($data['last_name']) ?></li>
            <li>Address: <?= htmlspecialchars($data['address']) ?></li>
            <li>City: <?= htmlspecialchars($data['city']) ?></li>
        </ul>
        <form method="post">
            <input type='hidden' name='staff_id' value='<?= $data['staff_id'] ?>'>
            <input type='hidden' name='address_id' value='<?= $data['address_id'] ?>'>
            <input type='hidden' name='city_id' value='<?= $data['city_id'] ?>'>
            <label>
                <input type='radio' name='confirm' value='yes'> Yes
            </label>
            <label>
                <input type='radio' name='confirm' value='no' checked> No
            </label>
            <button type="submit">Submit</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
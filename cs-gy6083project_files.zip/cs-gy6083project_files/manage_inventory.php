<?php
include 'dbconn.php';


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $carId = $_POST['car_id'];
    $storeId = $_POST['store_id'];

    $sql = "INSERT INTO inventory (car_id, store_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $carId, $storeId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Car added to inventory successfully!";
    } else {
        echo "Error adding car to inventory: " . $conn->error;
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove'])) {
    $inventoryId = $_POST['inventory_id'];

    $sql = "DELETE FROM inventory WHERE inventory_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $inventoryId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Car removed from inventory successfully!";
    } else {
        echo "Error removing car from inventory: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Inventory</title>
</head>
<body>
    <h2>Add Car to Inventory</h2>
    <form method="POST">
        Car ID: <input type="number" name="car_id" required><br>
        Store ID: <input type="number" name="store_id" required><br>
        <input type="submit" name="add" value="Add to Inventory">
    </form>

    <h2>Remove Car from Inventory</h2>
    <form method="POST">
        Inventory ID: <input type="number" name="inventory_id" required><br>
        <input type="submit" name="remove" value="Remove from Inventory">
    </form>
</body>
</html>

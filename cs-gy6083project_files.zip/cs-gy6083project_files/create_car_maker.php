<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include 'dbconn.php';

// Handle maker deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_maker_id'])) {
    $makerId = $_POST['delete_maker_id'];
    $deleteSql = "DELETE FROM maker WHERE maker_id = ?";
    $deleteStmt = $conn->prepare($deleteSql);
    $deleteStmt->bind_param("i", $makerId);
    $deleteStmt->execute();

    if ($deleteStmt->affected_rows > 0) {
        echo "<p>Maker deleted successfully!</p>";
    } else {
        echo "<p>Error deleting maker: " . $conn->error . "</p>";
    }
}

// Fetch existing makers
$makerQuery = "SELECT * FROM maker";
$makerResult = $conn->query($makerQuery);

if (!$makerResult) {
    die("SQL error: " . $conn->error);
}

// Handle new maker creation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['maker_name'])) {
    $makerName = $_POST['maker_name'];
    $makerNationality = $_POST['maker_nationality'];

    $sql = "INSERT INTO maker (maker_name, maker_nationality) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $makerName, $makerNationality);
    if ($stmt->execute()) {
        echo "Maker added successfully!";
    } else {
        echo "Error adding maker: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Maker</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #f4f4f4;
    }
    .container {
        width: auto;  
        min-width: 320px;  
        max-width: 95%;  
        margin: 20px auto;  
        padding: 20px;  
        background: white;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        overflow-x: auto;  
    }
    
    form {
        display: grid;
        grid-template-columns: repeat(2, 1fr); 
        gap: 10px;
        align-items: center;
        margin-bottom: 20px;
    }
    
    form label {
        text-align: right;
        padding-right: 10px;
    }
    
    input[type="text"], select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    
    input[type="submit"] {
        grid-column: 1 / 3; 
        justify-self: center; 
        padding: 10px 20px;
        color: white;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 50%; 
    }
    
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    
    th, td {
        text-align: left;
        padding: 8px;
        border: 1px solid #ddd;
    }
    
    th {
        background-color: #f8f8f8;
    }
    
    button {
        padding: 5px 10px;
        background-color: #f44336;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    
    button:hover {
        background-color: #d32f2f;
    }

</style>
</head>
<body>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <h2>Current Makers</h2>
    <table>
        <tr>
            <th>Maker ID</th>
            <th>Maker Name</th>
            <th>Nationality</th>
            <th>Action</th>
        </tr>
        <?php while($row = $makerResult->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['maker_id']); ?></td>
            <td><?php echo htmlspecialchars($row['maker_name']); ?></td>
            <td><?php echo htmlspecialchars($row['maker_nationality']); ?></td>
            <td>
                <a href="update_car_maker.php?maker_id=<?php echo $row['maker_id']; ?>">Edit</a>
                <form method="POST" onsubmit="return confirm('Are you sure you want to delete this maker?');" style="display: inline;">
                    <input type="hidden" name="delete_maker_id" value="<?php echo $row['maker_id']; ?>">
                    <input type="submit" value="Delete">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h3>Add New Maker</h3>
    <form method="POST">
        Maker Name: <input type="text" name="maker_name" required><br>
        Nationality: <input type="text" name="maker_nationality" required><br>
        <input type="submit" value="Add Maker">
    </form>
</body>
</html>

<?php
include('dbconn.php');  


function fetchDropdownOptions($conn, $table, $idColumn, $nameColumn) {
    $options = '';
    $sql = "SELECT $idColumn, $nameColumn FROM $table";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $options .= "<option value='" . $row[$idColumn] . "'>" . $row[$nameColumn] . "</option>";
    }
    return $options;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $storeName = mysqli_real_escape_string($conn, $_POST['storeName']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $address2 = mysqli_real_escape_string($conn, $_POST['address2']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $cityName = mysqli_real_escape_string($conn, $_POST['cityName']);
    $postalCode = mysqli_real_escape_string($conn, $_POST['postalCode']);
    $stateId = intval($_POST['state']);
    $countryId = intval($_POST['country']);

    
    $cityInsertSql = "INSERT INTO city (city, state_id, country_id) VALUES ('$cityName', $stateId, $countryId)";
    $conn->query($cityInsertSql);
    $cityId = $conn->insert_id;

    
    $addressInsertSql = "INSERT INTO address (address, address2, phone, city_id, postal_code) VALUES ('$address', '$address2', '$phone', $cityId, '$postalCode')";
    $conn->query($addressInsertSql);
    $addressId = $conn->insert_id;

    
    $storeInsertSql = "INSERT INTO store (store_name, address_id) VALUES ('$storeName', $addressId)";
    $conn->query($storeInsertSql);
}


$storeQuery = "SELECT * FROM ViewStoreDetails";
$stores = $conn->query($storeQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Store</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #f4f4f4;
    }
    .container {
        width: auto;  
        min-width: 320px;  
        max-width: 95%;  
        margin: 20px auto;  
        padding: 20px;  
        background: white;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        overflow-x: auto;  
    }
    
    form {
        display: grid;
        grid-template-columns: repeat(2, 1fr); 
        gap: 10px;
        align-items: center;
        margin-bottom: 20px;
    }
    
    form label {
        text-align: right;
        padding-right: 10px;
    }
    
    input[type="text"], select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    
    input[type="submit"] {
        grid-column: 1 / 3; 
        justify-self: center; 
        padding: 10px 20px;
        color: white;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 50%; 
    }
    
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    
    th, td {
        text-align: left;
        padding: 8px;
        border: 1px solid #ddd;
    }
    
    th {
        background-color: #f8f8f8;
    }
    
    button {
        padding: 5px 10px;
        background-color: #f44336;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    
    button:hover {
        background-color: #d32f2f;
    }

</style>
</head>
<body>
<div class="container">
    <br>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <h2>Create New Store</h2>
    <form action="create_store.php" method="post">
        <label for="storeName">Store Name:</label>
        <input type="text" id="storeName" name="storeName" required>
        
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required>
        
        <label for="address2">Address 2:</label>
        <input type="text" id="address2" name="address2">
        
        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" required>
        
        <label for="cityName">City Name:</label>
        <input type="text" id="cityName" name="cityName" required>
        
        <label for="postalCode">Postal Code:</label>
        <input type="text" id="postalCode" name="postalCode" required>
        
        <label for="state">State:</label>
        <select id="state" name="state" required>
            <?= fetchDropdownOptions($conn, 'state', 'state_id', 'state_name') ?>
        </select>
        
        <label for="country">Country:</label>
        <select id="country" name="country" required>
            <?= fetchDropdownOptions($conn, 'country', 'country_id', 'country') ?>
        </select>
        
        <input type="submit" value="Create Store">
    </form>

    <h2>Existing Stores</h2>
    <table>
        <tr>
            <th>Store ID</th>
            <th>Store Name</th>
            <th>Address</th>
            <th>Address 2</th>
            <th>Phone</th>
            <th>City Name</th>
            <th>Postal Code</th>
            <th>State</th>
            <th>Country</th>
            <th>Actions</th>
        </tr>
        <?php while ($store = $stores->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($store['store_id']) ?></td>
            <td><?= htmlspecialchars($store['store_name']) ?></td>
            <td><?= htmlspecialchars($store['address']) ?></td>
            <td><?= htmlspecialchars($store['address2']) ?></td>
            <td><?= htmlspecialchars($store['phone']) ?></td>
            <td><?= htmlspecialchars($store['city']) ?></td>
            <td><?= htmlspecialchars($store['postal_code']) ?></td>
            <td><?= htmlspecialchars($store['state_abbreviation']) ?></td>
            <td><?= htmlspecialchars($store['country_abbreviation']) ?></td>
            <td>
                <a href="update_store.php?store_id=<?= $store['store_id'] ?>">Update</a>
                <button onclick="if(confirm('Are you sure?')) { location.href='delete_store.php?store_id=<?= $store['store_id'] ?>' }">Delete</button>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>

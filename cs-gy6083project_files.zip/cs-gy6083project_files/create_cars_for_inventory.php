<?php
require_once 'dbconn.php'; 


function getMakers($conn) {
    $sql = "SELECT maker_id, maker_name FROM maker";
    $result = $conn->query($sql);
    $makers = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $makers[] = $row;
        }
    }
    return $makers;
}


function getAllCars($conn) {
    $sql = "CALL GetAllCars()";  // Using the stored procedure
    $result = $conn->query($sql);
    $cars = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cars[] = $row;
        }
    }
    return $cars;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $model_year = $_POST['model_year'];
    $rental_rate = $_POST['rental_rate'];
    $replacement_cost = $_POST['replacement_cost'];
    $maker_id = $_POST['maker_id'];

    // Insert into car_for_rent
    $sql = "INSERT INTO car_for_rent (title, description, model_year, rental_rate, replacement_cost) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssidi", $title, $description, $model_year, $rental_rate, $replacement_cost);
    if ($stmt->execute()) {
        $last_car_id = $stmt->insert_id;

        // Insert into car_maker
        $sql = "INSERT INTO car_maker (car_maker_id, car_id) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $maker_id, $last_car_id);
        if ($stmt->execute()) {
            echo "New car added successfully!";
        } else {
            echo "Error adding car to maker: " . $stmt->error;
        }
    } else {
        echo "Error adding car: " . $stmt->error;
    }
}

$makers = getMakers($conn);
$cars = getAllCars($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <title>Create Car Rental</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            margin-top: 20px;
            border: 1px solid #dddddd;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h2, h3 {
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Create New Car for Rent</h1>
    <form method="post">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br>
        <label for="description">Description:</label>
        <textarea id="description" name="description"></textarea><br>
        <label for="model_year">Model Year:</label>
        <input type="text" id="model_year" name="model_year"><br>
        <label for="rental_rate">Rental Rate:</label>
        <input type="text" id="rental_rate" name="rental_rate" required><br>
        <label for="replacement_cost">Replacement Cost:</label>
        <input type="text" id="replacement_cost" name="replacement_cost" required><br>
        <label for="maker_id">Maker:</label>
        <select id="maker_id" name="maker_id">
            <?php foreach ($makers as $maker): ?>
                <option value="<?= $maker['maker_id'] ?>"><?= $maker['maker_name'] ?></option>
            <?php endforeach; ?>
        </select><br>
        <button type="submit">Add Car</button>
    </form>
    <br>
    <a href="create_cars_for_inventory.php" class="back-button">Refresh The Pages</a>
    <br>
    <div id="available_cars">
        <h2>Available Cars</h2>
        <table id="cars_table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Model Year</th>
                    <th>Rental Rate</th>
                    <th>Replacement Cost</th>
                    <th>Maker</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cars as $car): ?>
                    <tr>
                        <td><?= htmlspecialchars($car['title']) ?></td>
                        <td><?= htmlspecialchars($car['description']) ?></td>
                        <td><?= htmlspecialchars($car['model_year']) ?></td>
                        <td><?= htmlspecialchars($car['rental_rate']) ?></td>
                        <td><?= htmlspecialchars($car['replacement_cost']) ?></td>
                        <td><?= htmlspecialchars($car['maker_name']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>


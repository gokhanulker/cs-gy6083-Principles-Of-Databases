<?php
require_once 'dbconn.php'; 

// Retrieve car data
$car_id = isset($_GET['car_id']) ? intval($_GET['car_id']) : 0;
if ($car_id == 0) {
    header('Location: update_car_for_rent.php'); // Redirect if no car_id is provided
    exit;
}


$sql = "SELECT * FROM car_for_rent WHERE car_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $car_id);
$stmt->execute();
$result = $stmt->get_result();
$car = $result->fetch_assoc();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $model_year = $_POST['model_year'];
    $rental_rate = $_POST['rental_rate'];
    $replacement_cost = $_POST['replacement_cost'];

    $updateSql = "UPDATE car_for_rent SET title = ?, description = ?, model_year = ?, rental_rate = ?, replacement_cost = ? WHERE car_id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("ssiddi", $title, $description, $model_year, $rental_rate, $replacement_cost, $car_id);
    if ($updateStmt->execute()) {
        echo "<p>Car updated successfully!</p>";
    } else {
        echo "<p>Error updating car: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Car</title>
</head>
<body>
    <h1>Edit Car</h1>
    <form method="post">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?= htmlspecialchars($car['title']) ?>" required><br>
        <label for="description">Description:</label>
        <textarea id="description" name="description"><?= htmlspecialchars($car['description']) ?></textarea><br>
        <label for="model_year">Model Year:</label>
        <input type="text" id="model_year" name="model_year" value="<?= htmlspecialchars($car['model_year']) ?>"><br>
        <label for="rental_rate">Rental Rate:</label>
        <input type="text" id="rental_rate" name="rental_rate" value="<?= htmlspecialchars($car['rental_rate']) ?>" required><br>
        <label for="replacement_cost">Replacement Cost:</label>
        <input type="text" id="replacement_cost" name="replacement_cost" value="<?= htmlspecialchars($car['replacement_cost']) ?>" required><br>
        <button type="submit">Update Car</button>
    </form>
    <a href="update_car_for_rent.php">Back to List</a>
</body>
</html>

<?php
include 'dbconn.php';

$makerId = $_GET['maker_id'];  

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE FROM maker WHERE maker_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $makerId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Car maker deleted successfully!";
    } else {
        echo "Error deleting car maker: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Car Maker</title>
</head>
<body>
    <h2>Delete Car Maker</h2>
    <form method="POST">
        <input type="submit" value="Delete Car Maker" onclick="return confirm('Are you sure you want to delete this car maker?');">
    </form>
</body>
</html>

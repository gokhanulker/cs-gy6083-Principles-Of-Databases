<?php
require_once 'dbconn.php'; 


function getAvailableCars($conn) {
    $sql = "SELECT * FROM car_for_rent WHERE car_id NOT IN (SELECT car_id FROM inventory)";
    $result = $conn->query($sql);
    $cars = [];
    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
    return $cars;
}


function getStores($conn) {
    $sql = "SELECT store_id, store_name FROM store";
    $result = $conn->query($sql);
    $stores = [];
    while ($row = $result->fetch_assoc()) {
        $stores[] = $row;
    }
    return $stores;
}


function getStoresWithNoInventory($conn) {
    $sql = "SELECT store_id, store_name FROM store WHERE has_inventory = FALSE";
    $result = $conn->query($sql);
    $emptyStores = [];
    while ($row = $result->fetch_assoc()) {
        $emptyStores[] = $row;
    }
    return $emptyStores;
}


function getInventory($conn) {
    $sql = "SELECT car_for_rent.*, store.store_name AS store_name
            FROM inventory
            INNER JOIN car_for_rent ON inventory.car_id = car_for_rent.car_id
            INNER JOIN store ON inventory.store_id = store.store_id";
    $result = $conn->query($sql);
    $inventory = [];
    while ($row = $result->fetch_assoc()) {
        $inventory[] = $row;
    }
    return $inventory;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['assign'])) {
    $car_id = $_POST['car_id'];
    $store_id = $_POST['store_id'];

    
    $checkSql = "SELECT * FROM inventory WHERE car_id = ?";
    $stmt = $conn->prepare($checkSql);
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        // If found, update the store_id for the existing record
        $updateSql = "UPDATE inventory SET store_id = ? WHERE car_id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("ii", $store_id, $car_id);
        $updateStmt->execute();
    } else {
        // If not found, insert a new inventory record
        $insertSql = "INSERT INTO inventory (car_id, store_id) VALUES (?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("ii", $car_id, $store_id);
        $insertStmt->execute();
    }
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page to avoid resubmission
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $car_id = $_POST['car_id'];
    $deleteSql = "DELETE FROM inventory WHERE car_id = ?";
    $deleteStmt = $conn->prepare($deleteSql);
    $deleteStmt->bind_param("i", $car_id);
    $deleteStmt->execute();
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
    exit;
}

$cars = getAvailableCars($conn);
$stores = getStores($conn);
$inventory = getInventory($conn);
$emptyStores = getStoresWithNoInventory($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create or Update Inventory</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .inventory-table-container {
            border: 1px solid #ddd;
            padding: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <br><br>
    <h1>Inventory Management</h1>

    <?php if (!empty($emptyStores)): ?>
    <div class="inventory-table-container">
        <h2>Stores with No Inventory</h2>
        <ul>
        <?php foreach ($emptyStores as $store): ?>
            <li>Store ID: <?= htmlspecialchars($store['store_id']) ?> - <?= htmlspecialchars($store['store_name']) ?></li>
        <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="inventory-table-container">
        <h2>All Available Cars</h2>
        <table>
            <thead>
                <tr>
                    <th>Car ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Model Year</th>
                    <th>Rental Rate</th>
                    <th>Replacement Cost</th>
                    <th>Last Update</th>
                    <th>Assign to Store</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($cars as $car): ?>
                <tr>
                    <td><?= htmlspecialchars($car['car_id']) ?></td>
                    <td><?= htmlspecialchars($car['title']) ?></td>
                    <td><?= htmlspecialchars($car['description']) ?></td>
                    <td><?= htmlspecialchars($car['model_year']) ?></td>
                    <td><?= htmlspecialchars($car['rental_rate']) ?></td>
                    <td><?= htmlspecialchars($car['replacement_cost']) ?></td>
                    <td><?= htmlspecialchars($car['last_update']) ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="car_id" value="<?= $car['car_id'] ?>">
                            <select name="store_id">
                                <?php foreach ($stores as $store): ?>
                                    <option value="<?= $store['store_id'] ?>"><?= htmlspecialchars($store['store_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="assign">Assign</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="inventory-table-container">
        <h2>Current Inventory</h2>
        <table>
            <thead>
                <tr>
                    <th>Car ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Model Year</th>
                    <th>Rental Rate</th>
                    <th>Replacement Cost</th>
                    <th>Last Update</th>
                    <th>Store</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($inventory as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['car_id']) ?></td>
                    <td><?= htmlspecialchars($item['title']) ?></td>
                    <td><?= htmlspecialchars($item['description']) ?></td>
                    <td><?= htmlspecialchars($item['model_year']) ?></td>
                    <td><?= htmlspecialchars($item['rental_rate']) ?></td>
                    <td><?= htmlspecialchars($item['replacement_cost']) ?></td>
                    <td><?= htmlspecialchars($item['last_update']) ?></td>
                    <td><?= htmlspecialchars($item['store_name']) ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="car_id" value="<?= $item['car_id'] ?>">
                            <button type="submit" name="delete">Remove from Inventory</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>

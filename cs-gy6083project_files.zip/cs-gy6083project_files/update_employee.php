<?php
include('dbconn.php'); 


function fetchDropdownOptions($conn, $table, $idColumn, $nameColumn, $selectedId = null) {
    $options = '';
    $sql = "SELECT $idColumn, $nameColumn FROM $table";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $selected = ($row[$idColumn] == $selectedId) ? 'selected' : '';
        $options .= "<option value='" . $row[$idColumn] . "' $selected>" . $row[$nameColumn] . "</option>";
    }
    return $options;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $staff_id = intval($_POST['staff_id']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $address2 = mysqli_real_escape_string($conn, $_POST['address2']);
    $postal_code = mysqli_real_escape_string($conn, $_POST['postal_code']);
    $city_name = mysqli_real_escape_string($conn, $_POST['city_name']);
    $state_id = intval($_POST['state']);
    $country_id = intval($_POST['country']);
    $city_id = intval($_POST['city_id']);

    
    $updateCitySql = "UPDATE city SET city = '$city_name', state_id = $state_id, country_id = $country_id WHERE city_id = $city_id";
    $conn->query($updateCitySql);

    
    $updateAddressSql = "UPDATE address SET address = '$address', address2 = '$address2', phone = '$phone', postal_code = '$postal_code' WHERE address_id = (SELECT address_id FROM staff WHERE staff_id = $staff_id)";
    $conn->query($updateAddressSql);

    
    $updateStaffSql = "UPDATE staff SET first_name = '$first_name', last_name = '$last_name', email = '$email' WHERE staff_id = $staff_id";
    if ($conn->query($updateStaffSql)) {
        header("Location: create_employee.php"); 
        exit();
    }
}


if (isset($_GET['staff_id'])) {
    $staff_id = intval($_GET['staff_id']);
    $query = "SELECT s.*, a.address, a.address2, a.phone, a.postal_code, c.city, c.city_id, c.state_id, c.country_id 
              FROM staff s
              JOIN address a ON s.address_id = a.address_id
              JOIN city c ON a.city_id = c.city_id
              WHERE s.staff_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Update Employee</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        width: 80%;
        margin: auto;
        background: white;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
        color: #333;
    }
    form {
        margin-top: 20px;
    }
    label, input, select {
        display: block;
        width: 100%;
        margin-top: 5px;
    }
    button {
        padding: 10px 20px;
        color: #fff;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    button:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>
<div class="container">
    <a href="create_employee.php" class="back-button">Back to Employee Creation Page</a>
    <h2>Update Employee</h2>
    <?php if (isset($data)): ?>
        <form method="post">
            <input type='hidden' name='staff_id' value='<?= $data['staff_id'] ?>'>
            <input type='hidden' name='city_id' value='<?= $data['city_id'] ?>'>
            <label>First Name:</label>
            <input type='text' name='first_name' value='<?= htmlspecialchars($data['first_name']) ?>' required>
            <label>Last Name:</label>
            <input type='text' name='last_name' value='<?= htmlspecialchars($data['last_name']) ?>' required>
            <label>Email:</label>
            <input type='email' name='email' value='<?= htmlspecialchars($data['email']) ?>'>
            <label>Phone:</label>
            <input type='text' name='phone' value='<?= htmlspecialchars($data['phone']) ?>'>
            <label>Address:</label>
            <input type='text' name='address' value='<?= htmlspecialchars($data['address']) ?>' required>
            <label>Address 2:</label>
            <input type='text' name='address2' value='<?= htmlspecialchars($data['address2']) ?>'>
            <label>Postal Code:</label>
            <input type='text' name='postal_code' value='<?= htmlspecialchars($data['postal_code']) ?>' required>
            <label>City:</label>
            <input type='text' name='city_name' value='<?= htmlspecialchars($data['city']) ?>' required>
            <label>State:</label>
            <select name="state" required>
                <?= fetchDropdownOptions($conn, 'state', 'state_id', 'state_name', $data['state_id']) ?>
            </select>
            <label>Country:</label>
            <select name="country" required>
                <?= fetchDropdownOptions($conn, 'country', 'country_id', 'country', $data['country_id']) ?>
            </select>
            <button type="submit" name="update">Update Employee</button>
        </form>
    <?php else: ?>
        <p>Employee not found.</p>
    <?php endif; ?>
</div>
</body>
</html>

<?php
require_once 'dbconn.php'; 


function getAllCars($conn) {
    $sql = "SELECT * FROM car_for_rent";
    $result = $conn->query($sql);
    $cars = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cars[] = $row;
        }
    }
    return $cars;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $car_id = $_POST['car_id'];
    $sql = "DELETE FROM car_for_rent WHERE car_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    header("Location: update_car_for_rent.php"); // Redirect to refresh the page and list
}

$cars = getAllCars($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <title>Update or Delete Car</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .frame {
            border: 2px solid #666;
            padding: 10px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <br>
    <br>
    <br>
    <a href="update_car_for_rent.php" class="back-button">Refresh The Pages</a>
    <div class="frame">
        <h2>Available Cars</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Model Year</th>
                    <th>Rental Rate</th>
                    <th>Replacement Cost</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cars as $car): ?>
                    <tr>
                        <td><?= htmlspecialchars($car['car_id']) ?></td>
                        <td><?= htmlspecialchars($car['title']) ?></td>
                        <td><?= htmlspecialchars($car['description']) ?></td>
                        <td><?= htmlspecialchars($car['model_year']) ?></td>
                        <td><?= htmlspecialchars($car['rental_rate']) ?></td>
                        <td><?= htmlspecialchars($car['replacement_cost']) ?></td>
                        <td>
                            <a href="edit_car.php?car_id=<?= $car['car_id'] ?>">Edit</a> |
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="car_id" value="<?= $car['car_id'] ?>">
                                <button type="submit" name="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
</body>
</html>

<?php
include('dbconn.php'); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['confirm']) && $_POST['confirm'] == 'yes') {
        
        $store_id = intval($_POST['store_id']);
        $address_id = intval($_POST['address_id']);
        $city_id = intval($_POST['city_id']);

        
        $conn->begin_transaction();

        try {
            
            $stmt = $conn->prepare("DELETE FROM store WHERE store_id = ?");
            $stmt->bind_param("i", $store_id);
            $stmt->execute();
            $stmt->close();

            
            $stmt = $conn->prepare("DELETE FROM address WHERE address_id = ?");
            $stmt->bind_param("i", $address_id);
            $stmt->execute();
            $stmt->close();

            
            $stmt = $conn->prepare("DELETE FROM city WHERE city_id = ?");
            $stmt->bind_param("i", $city_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            
            header("Location: create_store.php?deleted=true");
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo "An error occurred: " . $e->getMessage();
        }
    } elseif (isset($_POST['confirm']) && $_POST['confirm'] == 'no') {
        // If user selects 'No', redirect to create_store.php
        header("Location: create_store.php");
        exit();
    }
}

if (isset($_GET['store_id']) && !isset($_GET['deleted'])) {
    
    $store_id = intval($_GET['store_id']);
    $query = "SELECT s.store_id, s.store_name, a.address_id, a.address, c.city_id, c.city 
              FROM store s
              JOIN address a ON s.address_id = a.address_id
              JOIN city c ON a.city_id = c.city_id
              WHERE s.store_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $store_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();

    if (!$data) {
        echo "<p>Store not found.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Delete Store</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        width: 80%;
        margin: auto;
        background: white;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
        color: #333;
    }
    ul {
        list-style: none;
        padding: 0;
    }
    ul li {
        margin-bottom: 10px;
        font-size: 16px;
    }
    form {
        margin-top: 20px;
    }
    input[type="radio"] {
        margin-right: 5px;
    }
    button {
        padding: 10px 20px;
        color: #fff;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    button:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>
<div class="container">
    <?php if (isset($data)): ?>
        <br>
        <a href="create_store.php" class="back-button">Back to Store Operations</a>
        <h2>Confirm Deletion</h2>
        <p>Are you sure you want to delete the following store and its related address and city?</p>
        <ul>
            <li>Store Name: <?= htmlspecialchars($data['store_name']) ?></li>
            <li>Address: <?= htmlspecialchars($data['address']) ?></li>
            <li>City: <?= htmlspecialchars($data['city']) ?></li>
        </ul>
        <form method="post">
            <input type='hidden' name='store_id' value='<?= $data['store_id'] ?>'>
            <input type='hidden' name='address_id' value='<?= $data['address_id'] ?>'>
            <input type='hidden' name='city_id' value='<?= $data['city_id'] ?>'>
            <label>
                <input type='radio' name='confirm' value='yes'> Yes
            </label>
            <label>
                <input type='radio' name='confirm' value='no' checked> No
            </label>
            <button type="submit">Submit</button>
        </form>
    <?php elseif (isset($_GET['deleted'])): ?>
        <h2>Store Deleted Successfully</h2>
        <a href="create_store.php">Return to Store List</a>
    <?php endif; ?>
</div>
</body>
</html>

<?php
header("Cache-Control: no-cache");
$servername = "localhost";
$username = "ulkercor_rental";
$password = "Flagnut@12";
$dbname = "ulkercor_rental2";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 
?>
<?php
require 'dbconn.php'; 
session_start(); 
ob_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $makerId = $_POST['maker_id'];
    $makerName = $_POST['maker_name'];
    $makerNationality = $_POST['maker_nationality'];

    
    $updateSql = "UPDATE maker SET maker_name = ?, maker_nationality = ? WHERE maker_id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("ssi", $makerName, $makerNationality, $makerId);
    $updateStmt->execute();

    if ($updateStmt->affected_rows > 0) {
        $_SESSION['message'] = "Maker updated successfully!";
    } else {
        $_SESSION['message'] = "Error updating maker: " . $updateStmt->error;
    }
    header("Location: create_car_maker.php"); // Redirect back to the maker list
    exit;
}

if (isset($_GET['maker_id'])) {
    $makerId = $_GET['maker_id'];

    
    $query = "SELECT * FROM maker WHERE maker_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $makerId);
    $stmt->execute();
    $result = $stmt->get_result();
    $maker = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Car Maker</title>
</head>
<body>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <br>
    <h1>Update Car Maker</h1>
    <form method="POST">
        <input type="hidden" name="maker_id" value="<?php echo $makerId; ?>">
        Maker Name: <input type="text" name="maker_name" value="<?php echo htmlspecialchars($maker['maker_name']); ?>"><br>
        Nationality: <input type="text" name="maker_nationality" value="<?php echo htmlspecialchars($maker['maker_nationality']); ?>"><br>
        <input type="submit" value="Update Maker">
    </form>
</body>
</html>
<?php ob_end_flush(); // End output buffering and send output to browser ?>

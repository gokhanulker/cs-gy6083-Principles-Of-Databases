<?php
include('dbconn.php');  


$success = 0; 


function fetchDropdownOptions($conn, $table, $idColumn, $nameColumn, $selectedId = null) {
    $options = '';
    $sql = "SELECT $idColumn, $nameColumn FROM $table";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $selected = ($row[$idColumn] == $selectedId) ? 'selected' : '';
        $options .= "<option value='" . $row[$idColumn] . "' $selected>" . $row[$nameColumn] . "</option>";
    }
    return $options;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['store_id'])) {
    $store_id = intval($_POST['store_id']);
    $store_name = mysqli_real_escape_string($conn, $_POST['store_name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $address2 = mysqli_real_escape_string($conn, $_POST['address2']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $city_name = mysqli_real_escape_string($conn, $_POST['city_name']);
    $postal_code = mysqli_real_escape_string($conn, $_POST['postal_code']);
    $state_id = intval($_POST['state']);
    $country_id = intval($_POST['country']);

    
    $cityUpdateSql = "UPDATE city SET city = ?, state_id = ?, country_id = ? WHERE city_id = ?";
    $stmt = $conn->prepare($cityUpdateSql);
    $stmt->bind_param("siis", $city_name, $state_id, $country_id, $_POST['city_id']);
    if ($stmt->execute()) {
        $stmt->close();

        
        $addressUpdateSql = "UPDATE address SET address = ?, address2 = ?, phone = ?, postal_code = ? WHERE address_id = ?";
        $stmt = $conn->prepare($addressUpdateSql);
        $stmt->bind_param("sssii", $address, $address2, $phone, $postal_code, $_POST['address_id']);
        if ($stmt->execute()) {
            $stmt->close();

            
            $storeUpdateSql = "UPDATE store SET store_name = ? WHERE store_id = ?";
            $stmt = $conn->prepare($storeUpdateSql);
            $stmt->bind_param("si", $store_name, $store_id);
            if ($stmt->execute()) {
                $success = 1; // Set success to 1 on successful update
            }
            $stmt->close();
        }
    }

    
    header("Location: create_store.php?store_id=$store_id&success=$success");
    exit();
}


if (isset($_GET['store_id'])) {
    $store_id = intval($_GET['store_id']);
    $query = "SELECT s.store_id, s.store_name, a.address_id, a.address, a.address2, a.phone, a.postal_code, c.city_id, c.city, c.state_id, c.country_id 
              FROM store s
              JOIN address a ON s.address_id = a.address_id
              JOIN city c ON a.city_id = c.city_id
              WHERE s.store_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $store_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $store = $result->fetch_assoc();
    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Update Store</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #f4f4f4;
    }
    .container {
        width: auto;  
        min-width: 320px;  
        max-width: 95%;  
        margin: 20px auto;  
        padding: 20px;  
        background: white;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        overflow-x: auto;  
    }
    form {
        display: grid;
        grid-template-columns: repeat(2, 1fr); 
        gap: 10px;
        align-items: center;
        margin-bottom: 20px;
    }
    form label {
        text-align: right;
        padding-right: 10px;
    }
    input[type="text"], select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    input[type="submit"] {
        grid-column: 1 / 3; 
        justify-self: center; 
        padding: 10px 20px;
        color: white;
        background-color: #007BFF;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 50%; 
    }
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>
<?php

if (isset($_GET['update_success']) && $_GET['update_success'] == 1) {
    echo '<p style="color: green;">Store updated successfully!</p>';
}
?>
<div class="container">
    <?php if ($success): ?>
        <p>Store updated successfully.</p>
    <?php endif; ?>
    <br>
    <a href="create_store.php" class="back-button">Back to Store Operations</a>
    <h2>Update Store</h2>
    <?php if ($store): ?>
    <form action="update_store.php" method="post">
        <input type="hidden" name="store_id" value="<?= $store['store_id'] ?>">
        <input type="hidden" name="address_id" value="<?= $store['address_id'] ?>">
        <input type="hidden" name="city_id" value="<?= $store['city_id'] ?>">
        Store Name: <input type="text" name="store_name" value="<?= htmlspecialchars($store['store_name']) ?>" required><br>
        Address: <input type="text" name="address" value="<?= htmlspecialchars($store['address']) ?>" required><br>
        Address 2: <input type="text" name="address2" value="<?= htmlspecialchars($store['address2']) ?>"><br>
        Phone: <input type="text" name="phone" value="<?= htmlspecialchars($store['phone']) ?>" required><br>
        City Name: <input type="text" name="city_name" value="<?= htmlspecialchars($store['city']) ?>" required><br>
        Postal Code: <input type="text" name="postal_code" value="<?= htmlspecialchars($store['postal_code']) ?>" required><br>
        State: <select name="state" required>
            <?= fetchDropdownOptions($conn, 'state', 'state_id', 'state_name', $store['state_id']) ?>
        </select><br>
        Country: <select name="country" required>
            <?= fetchDropdownOptions($conn, 'country', 'country_id', 'country', $store['country_id']) ?>
        </select><br>
        <input type="submit" value="Update Store">
    </form>
    <?php else: ?>
    <p>No store found, or invalid store ID.</p>
    <?php endif; ?>
</div>
</body>
</html>

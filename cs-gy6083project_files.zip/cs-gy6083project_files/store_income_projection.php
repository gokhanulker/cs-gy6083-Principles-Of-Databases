<?php
include('dbconn.php'); 

$storeDetails = [];
$days = 30; // Default to maximum 30 days

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['days'])) {
    $days = intval($_POST['days']);
    $days = max(1, min($days, 30)); 
}


$stores = $conn->query("SELECT store_id, store_name FROM store");

if ($stores) {
    while ($store = $stores->fetch_assoc()) {
        $store_id = $store['store_id'];
        $store_name = $store['store_name'];
        $maxRate = $conn->query("SELECT GetMaxRentalRate($store_id) AS MaxRate")->fetch_object()->MaxRate;
        $avgRate = $conn->query("SELECT GetAvgRentalRate($store_id) AS AvgRate")->fetch_object()->AvgRate;
        $minRate = $conn->query("SELECT GetMinRentalRate($store_id) AS MinRate")->fetch_object()->MinRate;

        $monthlyIncome = [
            'max' => $maxRate * $days,
            'avg' => $avgRate * $days,
            'min' => $minRate * $days
        ];
        $quarterlyIncome = [
            'max' => 3 * $monthlyIncome['max'],
            'avg' => 3 * $monthlyIncome['avg'],
            'min' => 3 * $monthlyIncome['min']
        ];
        $semiAnnualIncome = [
            'max' => 6 * $monthlyIncome['max'],
            'avg' => 6 * $monthlyIncome['avg'],
            'min' => 6 * $monthlyIncome['min']
        ];
        $annualIncome = [
            'max' => 12 * $monthlyIncome['max'],
            'avg' => 12 * $monthlyIncome['avg'],
            'min' => 12 * $monthlyIncome['min']
        ];

        $storeDetails[] = [
            'store_id' => $store_id,
            'store_name' => $store_name,
            'max_rate' => $maxRate,
            'avg_rate' => $avgRate,
            'min_rate' => $minRate,
            'monthly_income' => $monthlyIncome,
            'quarterly_income' => $quarterlyIncome,
            'semi_annual_income' => $semiAnnualIncome,
            'annual_income' => $annualIncome
        ];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Store Income Projections</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2, h3 {
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        label, input, button {
            display: block;
            width: 100%;
            margin-top: 5px;
        }
        button {
            padding: 10px 20px;
            color: #fff;
            background-color: #007BFF;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <h2>Store Rental Rates and Income Projections</h2>
    <form method="post">
        <label for="days">Enter the number of occupancy days for the inventory (Choose between 1 - 30. Initial Calculation is 30 days):</label>
        <input type="number" id="days" name="days" min="1" max="30" required>
        <button type="submit">Calculate Projections</button>
    </form>
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <p><strong>Number of occupancy days chosen: <?php echo $days; ?> days</strong></p>
    <?php endif; ?>
    <?php foreach ($storeDetails as $details): ?>
        <h3>Store ID: <?php echo $details['store_id']; ?> - Store Name: <?php echo htmlspecialchars($details['store_name']); ?></h3>
        <table>
            <tr>
                <th>Projection Period</th>
                <th>Maximum Income ($)</th>
                <th>Average Income ($)</th>
                <th>Minimum Income ($)</th>
            </tr>
            <tr>
                <td>Monthly</td>
                <td><?php echo number_format($details['monthly_income']['max'], 2); ?></td>
                <td><?php echo number_format($details['monthly_income']['avg'], 2); ?></td>
                <td><?php echo number_format($details['monthly_income']['min'], 2); ?></td>
            </tr>
            <tr>
                <td>Quarterly</td>
                <td><?php echo number_format($details['quarterly_income']['max'], 2); ?></td>
                <td><?php echo number_format($details['quarterly_income']['avg'], 2); ?></td>
                <td><?php echo number_format($details['quarterly_income']['min'], 2); ?></td>
            </tr>
            <tr>
                <td>Semi-Annually</td>
                <td><?php echo number_format($details['semi_annual_income']['max'], 2); ?></td>
                <td><?php echo number_format($details['semi_annual_income']['avg'], 2); ?></td>
                <td><?php echo number_format($details['semi_annual_income']['min'], 2); ?></td>
            </tr>
            <tr>
                <td>Annually</td>
                <td><?php echo number_format($details['annual_income']['max'], 2); ?></td>
                <td><?php echo number_format($details['annual_income']['avg'], 2); ?></td>
                <td><?php echo number_format($details['annual_income']['min'], 2); ?></td>
            </tr>
        </table>
    <?php endforeach; ?>
</div>
</body>
</html>

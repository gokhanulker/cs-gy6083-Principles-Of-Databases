-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 02, 2024 at 07:06 PM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ulkercor_rental2`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`cpses_ul4gr7bfiv`@`localhost` PROCEDURE `EnsureStoreDetails` (IN `p_store_id` INT, IN `p_store_name` VARCHAR(255), IN `p_address` VARCHAR(50), IN `p_address2` VARCHAR(50), IN `p_district` VARCHAR(20), IN `p_postal_code` VARCHAR(10), IN `p_phone` VARCHAR(20), IN `p_city` VARCHAR(50), IN `p_state` VARCHAR(50), IN `p_country` VARCHAR(50), OUT `p_result` VARCHAR(255))   BEGIN
    DECLARE v_country_id INT;
    DECLARE v_city_id INT;
    DECLARE v_address_id INT;

    -- Check or insert country
    SELECT country_id INTO v_country_id FROM country WHERE country = p_country;
    IF v_country_id IS NULL THEN
        INSERT INTO country (country) VALUES (p_country);
        SET v_country_id = LAST_INSERT_ID();
    END IF;

    -- Check or insert city
    SELECT city_id INTO v_city_id FROM city WHERE city = p_city AND state = p_state AND country_id = v_country_id;
    IF v_city_id IS NULL THEN
        INSERT INTO city (city, state, country_id) VALUES (p_city, p_state, v_country_id);
        SET v_city_id = LAST_INSERT_ID();
    END IF;

    -- Check or insert address
    SELECT address_id INTO v_address_id FROM address WHERE address = p_address AND city_id = v_city_id;
    IF v_address_id IS NULL THEN
        INSERT INTO address (address, address2, district, city_id, postal_code, phone) VALUES (p_address, p_address2, p_district, v_city_id, p_postal_code, p_phone);
        SET v_address_id = LAST_INSERT_ID();
    ELSE
        UPDATE address SET address2 = p_address2, district = p_district, postal_code = p_postal_code, phone = p_phone WHERE address_id = v_address_id;
    END IF;

    -- Update or insert store
    IF p_store_id = 0 THEN
        INSERT INTO store (store_name, address_id) VALUES (p_store_name, v_address_id);
        SET p_result = 'Store created successfully';
    ELSE
        UPDATE store SET store_name = p_store_name, address_id = v_address_id WHERE store_id = p_store_id;
        SET p_result = 'Store updated successfully';
    END IF;

END$$
CREATE DEFINER=`cpses_ulok2qclbv`@`localhost` PROCEDURE `GetAllCars` ()   BEGIN
    SELECT c.car_id, c.title, c.description, c.model_year, c.rental_rate, c.replacement_cost, m.maker_name 
    FROM car_for_rent c
    JOIN car_maker cm ON c.car_id = cm.car_id
    JOIN maker m ON cm.car_maker_id = m.maker_id;
END$$

$$

CREATE DEFINER=`cpses_ul4gr7bfiv`@`localhost` PROCEDURE `updateStoreDetails` (IN `p_store_id` TINYINT UNSIGNED, IN `p_store_name` VARCHAR(255), IN `p_address` VARCHAR(50), IN `p_address2` VARCHAR(50), IN `p_district` VARCHAR(20), IN `p_city_id` SMALLINT UNSIGNED, IN `p_postal_code` VARCHAR(10), IN `p_phone` VARCHAR(20))   BEGIN
    DECLARE v_address_id SMALLINT UNSIGNED;

    -- Get the current address ID from the store
    SELECT address_id INTO v_address_id FROM store WHERE store_id = p_store_id;

    -- Update the address details
    UPDATE address
    SET address = p_address, address2 = p_address2, district = p_district, city_id = p_city_id, postal_code = p_postal_code, phone = p_phone
    WHERE address_id = v_address_id;

    -- Update the store details
    UPDATE store
    SET store_name = p_store_name
    WHERE store_id = p_store_id;

END$$

DELIMITER ;


--
-- Functions
--
CREATE DEFINER=`cpses_ulczrbi871`@`localhost` FUNCTION `GetAvgRentalRate` (`store_id` INT) RETURNS DECIMAL(7,2)  BEGIN
    DECLARE avg_rate DECIMAL(7,2);
    SELECT AVG(c.rental_rate) INTO avg_rate
    FROM inventory i
    JOIN car_for_rent c ON i.car_id = c.car_id
    WHERE i.store_id = store_id;
    RETURN avg_rate;
END$$

CREATE DEFINER=`cpses_ulczrbi871`@`localhost` FUNCTION `GetMaxRentalRate` (`store_id` INT) RETURNS DECIMAL(7,2)  BEGIN
    DECLARE max_rate DECIMAL(7,2);
    SELECT MAX(c.rental_rate) INTO max_rate
    FROM inventory i
    JOIN car_for_rent c ON i.car_id = c.car_id
    WHERE i.store_id = store_id;
    RETURN max_rate;
END$$

CREATE DEFINER=`cpses_ulczrbi871`@`localhost` FUNCTION `GetMinRentalRate` (`store_id` INT) RETURNS DECIMAL(7,2)  BEGIN
    DECLARE min_rate DECIMAL(7,2);
    SELECT MIN(c.rental_rate) INTO min_rate
    FROM inventory i
    JOIN car_for_rent c ON i.car_id = c.car_id
    WHERE i.store_id = store_id;
    RETURN min_rate;
END$$

DELIMITER ;

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` smallint(5) UNSIGNED NOT NULL,
  `address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` smallint(5) UNSIGNED NOT NULL,
  `postal_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address_id`, `address`, `address2`, `phone`, `city_id`, `postal_code`, `last_update`) VALUES
(642, '1 Pilot Way', 'Apt 128933', '212-888-5555', 631, '7310', '2024-05-02 22:41:27');

-- --------------------------------------------------------

--
-- Table structure for table `car_for_rent`
--

CREATE TABLE `car_for_rent` (
  `car_id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `model_year` year(4) DEFAULT NULL,
  `rental_rate` decimal(7,2) NOT NULL DEFAULT '4.99',
  `replacement_cost` decimal(7,2) NOT NULL DEFAULT '19.99',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `car_for_rent`
--

INSERT INTO `car_for_rent` (`car_id`, `title`, `description`, `model_year`, `rental_rate`, `replacement_cost`, `last_update`) VALUES
(1010, '23BNC2346', '4 Door Sedan', '2021', 89.50, 16578.00, '2024-05-02 21:12:30');

-- --------------------------------------------------------

--
-- Table structure for table `car_maker`
--

CREATE TABLE `car_maker` (
  `car_maker_id` smallint(5) UNSIGNED NOT NULL,
  `car_id` smallint(5) UNSIGNED NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `car_maker`
--

INSERT INTO `car_maker` (`car_maker_id`, `car_id`, `last_update`) VALUES
(208, 1010, '2024-05-02 21:12:13');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` smallint(5) UNSIGNED NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` smallint(5) UNSIGNED NOT NULL,
  `country_id` smallint(5) UNSIGNED NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city`, `state_id`, `country_id`, `last_update`) VALUES
(631, 'Jersey City', 30, 125, '2024-05-02 22:41:27');

-- --------------------------------------------------------

--
-- Stand-in structure for view `CityCountryView`
-- 
--
CREATE TABLE `CityCountryView` (
`city_id` smallint(5) unsigned
,`city` varchar(50)
,`country` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` smallint(5) UNSIGNED NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_abbreviation` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country`, `country_abbreviation`, `last_update`) VALUES
(125, 'United States', 'USA', '2024-05-02 18:58:29'),
(126, 'Canada', 'CAN', '2024-05-02 18:58:29'),
(127, 'Mexico', 'MEX', '2024-05-02 18:58:29');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` mediumint(8) UNSIGNED NOT NULL,
  `car_id` smallint(5) UNSIGNED NOT NULL,
  `store_id` tinyint(3) UNSIGNED NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `car_id`, `store_id`, `last_update`) VALUES
(4602, 1010, 21, '2024-05-03 00:46:27');

-- --------------------------------------------------------

--
-- Table structure for table `maker`
--

CREATE TABLE `maker` (
  `maker_id` smallint(5) UNSIGNED NOT NULL,
  `maker_name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maker_nationality` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `maker`
--

INSERT INTO `maker` (`maker_id`, `maker_name`, `maker_nationality`, `last_update`) VALUES
(207, 'Toyota', 'Japan', '2024-05-02 21:08:17'),
(208, 'Chevy', 'USA', '2024-05-02 21:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` tinyint(3) UNSIGNED NOT NULL,
  `first_name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_id` smallint(5) UNSIGNED NOT NULL,
  `username` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `store_id` tinyint(3) UNSIGNED NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` smallint(5) UNSIGNED NOT NULL,
  `state_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_abbreviation` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`, `state_abbreviation`, `last_update`) VALUES
(1, 'Alabama', 'AL', '2024-05-02 18:49:30'),
(2, 'Alaska', 'AK', '2024-05-02 18:49:30'),
(3, 'Arizona', 'AZ', '2024-05-02 18:49:30'),
(4, 'Arkansas', 'AR', '2024-05-02 18:49:30'),
(5, 'California', 'CA', '2024-05-02 18:49:30'),
(6, 'Colorado', 'CO', '2024-05-02 18:49:30'),
(7, 'Connecticut', 'CT', '2024-05-02 18:49:30'),
(8, 'Delaware', 'DE', '2024-05-02 18:49:30'),
(9, 'Florida', 'FL', '2024-05-02 18:49:30'),
(10, 'Georgia', 'GA', '2024-05-02 18:49:30'),
(11, 'Hawaii', 'HI', '2024-05-02 18:49:30'),
(12, 'Idaho', 'ID', '2024-05-02 18:49:30'),
(13, 'Illinois', 'IL', '2024-05-02 18:49:30'),
(14, 'Indiana', 'IN', '2024-05-02 18:49:30'),
(15, 'Iowa', 'IA', '2024-05-02 18:49:30'),
(16, 'Kansas', 'KS', '2024-05-02 18:49:30'),
(17, 'Kentucky', 'KY', '2024-05-02 18:49:30'),
(18, 'Louisiana', 'LA', '2024-05-02 18:49:30'),
(19, 'Maine', 'ME', '2024-05-02 18:49:30'),
(20, 'Maryland', 'MD', '2024-05-02 18:49:30'),
(21, 'Massachusetts', 'MA', '2024-05-02 18:49:30'),
(22, 'Michigan', 'MI', '2024-05-02 18:49:30'),
(23, 'Minnesota', 'MN', '2024-05-02 18:49:30'),
(24, 'Mississippi', 'MS', '2024-05-02 18:49:30'),
(25, 'Missouri', 'MO', '2024-05-02 18:49:30'),
(26, 'Montana', 'MT', '2024-05-02 18:49:30'),
(27, 'Nebraska', 'NE', '2024-05-02 18:49:30'),
(28, 'Nevada', 'NV', '2024-05-02 18:49:30'),
(29, 'New Hampshire', 'NH', '2024-05-02 18:49:30'),
(30, 'New Jersey', 'NJ', '2024-05-02 18:49:30'),
(31, 'New Mexico', 'NM', '2024-05-02 18:49:30'),
(32, 'New York', 'NY', '2024-05-02 18:49:30'),
(33, 'North Carolina', 'NC', '2024-05-02 18:49:30'),
(34, 'North Dakota', 'ND', '2024-05-02 18:49:30'),
(35, 'Ohio', 'OH', '2024-05-02 18:49:30'),
(36, 'Oklahoma', 'OK', '2024-05-02 18:49:30'),
(37, 'Oregon', 'OR', '2024-05-02 18:49:30'),
(38, 'Pennsylvania', 'PA', '2024-05-02 18:49:30'),
(39, 'Rhode Island', 'RI', '2024-05-02 18:49:30'),
(40, 'South Carolina', 'SC', '2024-05-02 18:49:30'),
(41, 'South Dakota', 'SD', '2024-05-02 18:49:30'),
(42, 'Tennessee', 'TN', '2024-05-02 18:49:30'),
(43, 'Texas', 'TX', '2024-05-02 18:49:30'),
(44, 'Utah', 'UT', '2024-05-02 18:49:30'),
(45, 'Vermont', 'VT', '2024-05-02 18:49:30'),
(46, 'Virginia', 'VA', '2024-05-02 18:49:30'),
(47, 'Washington', 'WA', '2024-05-02 18:49:30'),
(48, 'West Virginia', 'WV', '2024-05-02 18:49:30'),
(49, 'Wisconsin', 'WI', '2024-05-02 18:49:30'),
(50, 'Wyoming', 'WY', '2024-05-02 18:49:30');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `store_id` tinyint(3) UNSIGNED NOT NULL,
  `address_id` smallint(5) UNSIGNED NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `store_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`store_id`, `address_id`, `last_update`, `store_name`) VALUES
(21, 642, '2024-05-02 22:48:13', 'Newark Skylark');

-- --------------------------------------------------------

--
-- Stand-in structure for view `StoreInventoryView`
-- 
--
CREATE TABLE `StoreInventoryView` (
`inventory_id` mediumint(8) unsigned
,`car_id` smallint(5) unsigned
,`title` varchar(128)
,`description` text
,`rental_rate` decimal(7,2)
,`model_year` year(4)
,`store_name` varchar(255)
,`store_id` tinyint(3) unsigned
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password_hash`) VALUES
(1, 'admin', '$2y$10$uxVuIH3tffHaySvx6rjC1uKbvgBaBjfzeLoHGXrBGWvrMGbVrlxua');

-- --------------------------------------------------------

--
-- Stand-in structure for view `ViewCarMakers`
-- 
--
CREATE TABLE `ViewCarMakers` (
`maker_id` smallint(5) unsigned
,`maker_name` varchar(45)
,`maker_nationality` varchar(45)
);

-- --------------------------------------------------------

--
-- Table structure for table `ViewEmployeeDetails`
--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ViewEmployeeDetails`  AS SELECT `s`.`staff_id` AS `EmployeeID`, `s`.`first_name` AS `first_name`, `s`.`last_name` AS `last_name`, `s`.`email` AS `email`, `s`.`address_id` AS `address_id`, `a`.`address` AS `address`, `c`.`city` AS `city`, `c`.`state` AS `state`, `co`.`country` AS `country`, `s`.`store_id` AS `store_id` FROM ((((`staff` `s` join `address` `a` on((`s`.`address_id` = `a`.`address_id`))) join `city` `c` on((`a`.`city_id` = `c`.`city_id`))) join `country` `co` on((`c`.`country_id` = `co`.`country_id`))) left join `store` `st` on((`s`.`store_id` = `st`.`store_id`))) ;


-- --------------------------------------------------------

--
-- Stand-in structure for view `ViewStoreDetails`
-- 
--
CREATE TABLE `ViewStoreDetails` (
`store_id` tinyint(3) unsigned
,`store_name` varchar(255)
,`address_id` smallint(5) unsigned
,`address` varchar(50)
,`address2` varchar(50)
,`postal_code` varchar(10)
,`phone` varchar(20)
,`city_id` smallint(5) unsigned
,`city` varchar(50)
,`state_id` smallint(5) unsigned
,`state_name` varchar(50)
,`state_abbreviation` varchar(2)
,`country_id` smallint(5) unsigned
,`country` varchar(50)
,`country_abbreviation` varchar(3)
);

-- --------------------------------------------------------

--
-- Structure for view `CityCountryView`
--
DROP TABLE IF EXISTS `CityCountryView`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `CityCountryView`  AS SELECT `city`.`city_id` AS `city_id`, `city`.`city` AS `city`, `country`.`country` AS `country` FROM (`city` join `country` on((`city`.`country_id` = `country`.`country_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `StoreInventoryView`
--
DROP TABLE IF EXISTS `StoreInventoryView`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `StoreInventoryView`  AS SELECT `i`.`inventory_id` AS `inventory_id`, `i`.`car_id` AS `car_id`, `c`.`title` AS `title`, `c`.`description` AS `description`, `c`.`rental_rate` AS `rental_rate`, `c`.`model_year` AS `model_year`, `s`.`store_name` AS `store_name`, `s`.`store_id` AS `store_id` FROM ((`inventory` `i` join `car_for_rent` `c` on((`i`.`car_id` = `c`.`car_id`))) join `store` `s` on((`i`.`store_id` = `s`.`store_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `ViewCarMakers`
--
DROP TABLE IF EXISTS `ViewCarMakers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ViewCarMakers`  AS SELECT `maker`.`maker_id` AS `maker_id`, `maker`.`maker_name` AS `maker_name`, `maker`.`maker_nationality` AS `maker_nationality` FROM `maker` ;

-- --------------------------------------------------------

--
-- Structure for view `ViewStoreDetails`
--
DROP TABLE IF EXISTS `ViewStoreDetails`;

CREATE ALGORITHM=UNDEFINED DEFINER=`cpses_ul4gr7bfiv`@`localhost` SQL SECURITY DEFINER VIEW `ViewStoreDetails`  AS SELECT `s`.`store_id` AS `store_id`, `s`.`store_name` AS `store_name`, `a`.`address_id` AS `address_id`, `a`.`address` AS `address`, `a`.`address2` AS `address2`, `a`.`postal_code` AS `postal_code`, `a`.`phone` AS `phone`, `c`.`city_id` AS `city_id`, `c`.`city` AS `city`, `st`.`state_id` AS `state_id`, `st`.`state_name` AS `state_name`, `st`.`state_abbreviation` AS `state_abbreviation`, `co`.`country_id` AS `country_id`, `co`.`country` AS `country`, `co`.`country_abbreviation` AS `country_abbreviation` FROM ((((`store` `s` join `address` `a` on((`s`.`address_id` = `a`.`address_id`))) join `city` `c` on((`a`.`city_id` = `c`.`city_id`))) join `state` `st` on((`c`.`state_id` = `st`.`state_id`))) join `country` `co` on((`c`.`country_id` = `co`.`country_id`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`),
  ADD KEY `idx_fk_city_id` (`city_id`);

--
-- Indexes for table `car_for_rent`
--
ALTER TABLE `car_for_rent`
  ADD PRIMARY KEY (`car_id`),
  ADD KEY `idx_title` (`title`);

--
-- Indexes for table `car_maker`
--
ALTER TABLE `car_maker`
  ADD PRIMARY KEY (`car_maker_id`,`car_id`),
  ADD KEY `idx_fk_car_id` (`car_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`),
  ADD KEY `idx_fk_country_id` (`country_id`),
  ADD KEY `fk_city_state_idx` (`state_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD UNIQUE KEY `car_id_UNIQUE` (`car_id`),
  ADD UNIQUE KEY `store_id_UNIQUE` (`store_id`),
  ADD KEY `idx_fk_car_id` (`car_id`),
  ADD KEY `idx_store_id_car_id` (`store_id`,`car_id`);

--
-- Indexes for table `maker`
--
ALTER TABLE `maker`
  ADD PRIMARY KEY (`maker_id`),
  ADD KEY `idx_maker_maker_name` (`maker_name`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD KEY `fk_staff_name_idx` (`last_name`),
  ADD KEY `fk_staff_address_idx` (`address_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`store_id`),
  ADD KEY `idx_fk_address_id` (`address_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `address_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=643;

--
-- AUTO_INCREMENT for table `car_for_rent`
--
ALTER TABLE `car_for_rent`
  MODIFY `car_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1011;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=632;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4603;

--
-- AUTO_INCREMENT for table `maker`
--
ALTER TABLE `maker`
  MODIFY `maker_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `state_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `store_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `fk_address_city` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `car_maker`
--
ALTER TABLE `car_maker`
  ADD CONSTRAINT `fk_car_maker_car` FOREIGN KEY (`car_id`) REFERENCES `car_for_rent` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_car_maker_maker` FOREIGN KEY (`car_maker_id`) REFERENCES `maker` (`maker_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `fk_city_country` FOREIGN KEY (`country_id`) REFERENCES `country` (`country_id`),
  ADD CONSTRAINT `fk_city_state` FOREIGN KEY (`state_id`) REFERENCES `state` (`state_id`);

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `fk_inventory_car` FOREIGN KEY (`car_id`) REFERENCES `car_for_rent` (`car_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_inventory_store` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `fk_staff_address` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `store`
--
ALTER TABLE `store`
  ADD CONSTRAINT `fk_store_address` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
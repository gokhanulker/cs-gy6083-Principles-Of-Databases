<?php
require_once 'dbconn.php'; 


function getAvailableStaff($conn) {
    $sql = "SELECT staff_id, first_name, last_name FROM staff WHERE store_id IS NULL";
    $result = $conn->query($sql);
    $staff = [];
    while ($row = $result->fetch_assoc()) {
        $staff[] = $row;
    }
    return $staff;
}


function getStores($conn) {
    $sql = "SELECT store_id, store_name FROM store";
    $result = $conn->query($sql);
    $stores = [];
    while ($row = $result->fetch_assoc()) {
        $stores[] = $row;
    }
    return $stores;
}


function getCurrentAssignments($conn) {
    $sql = "SELECT staff.staff_id, staff.first_name, staff.last_name, store.store_name 
            FROM staff 
            JOIN store ON staff.store_id = store.store_id";
    $result = $conn->query($sql);
    $assignments = [];
    while ($row = $result->fetch_assoc()) {
        $assignments[] = $row;
    }
    return $assignments;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['assign'])) {
    $staff_id = $_POST['staff_id'];
    $store_id = $_POST['store_id'];
    
    $updateSql = "UPDATE staff SET store_id = ? WHERE staff_id = ?";
    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("ii", $store_id, $staff_id);
    $stmt->execute();
    
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove'])) {
    $staff_id = $_POST['staff_id'];
    
    $updateSql = "UPDATE staff SET store_id = NULL WHERE staff_id = ?";
    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
    exit;
}

$availableStaff = getAvailableStaff($conn);
$stores = getStores($conn);
$currentAssignments = getCurrentAssignments($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <br>
    <a href="adminoperations.php" class="back-button">Back to Admin Operations</a>
    <br>
    <title>Manage Staff Assignments</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Staff Management</h1>

    <div class="inventory-table-container">
        <h2>Available Staff</h2>
        <table>
            <thead>
                <tr>
                    <th>Staff ID</th>
                    <th>Name</th>
                    <th>Assign to Store</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($availableStaff as $staff): ?>
                <tr>
                    <td><?= htmlspecialchars($staff['staff_id']) ?></td>
                    <td><?= htmlspecialchars($staff['first_name']) . ' ' . htmlspecialchars($staff['last_name']) ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="staff_id" value="<?= $staff['staff_id'] ?>">
                            <select name="store_id">
                                <?php foreach ($stores as $store): ?>
                                    <option value="<?= $store['store_id'] ?>"><?= htmlspecialchars($store['store_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="assign">Assign</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="inventory-table-container">
        <h2>Current Staff Assignments</h2>
        <table>
            <thead>
                <tr>
                    <th>Staff ID</th>
                    <th>Name</th>
                    <th>Store</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($currentAssignments as $assignment): ?>
                <tr>
                    <td><?= htmlspecialchars($assignment['staff_id']) ?></td>
                    <td><?= htmlspecialchars($assignment['first_name']) . ' ' . htmlspecialchars($assignment['last_name']) ?></td>
                    <td><?= htmlspecialchars($assignment['store_name']) ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="staff_id" value="<?= $assignment['staff_id'] ?>">
                            <button type="submit" name="remove">Remove from Store</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
